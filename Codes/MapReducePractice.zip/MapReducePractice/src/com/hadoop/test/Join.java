package com.hadoop.test;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;


public class Join{
	public static void main(String [] args) throws IOException, ClassNotFoundException, InterruptedException
	{
		Configuration conf = new Configuration();
		String[] files=new GenericOptionsParser(conf,args).getRemainingArgs();
		Path input=new Path(files[0]);
		Path output=new Path(files[1]);
		Job job = new Job(conf, "GroupMR");
		job.setJarByClass(Join.class);
		job.setMapperClass(MapFortotalCount.class);
		job.setReducerClass(ReduceJoin.class);
		job.setOutputKeyClass(CompositeGroupKey.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.setMaxInputSplitSize(job, 10);
		FileInputFormat.setMinInputSplitSize(job, 100);
		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

	private static class CompositeGroupKey implements WritableComparable<CompositeGroupKey> {

		Text store;
		Text dept;

		public CompositeGroupKey(Text store, Text dept) {
			this.store = store;
			this.dept = dept;
		}
		public CompositeGroupKey() {
			this.store = new Text();
			this.dept = new Text();

		}
		public void write(DataOutput out) throws IOException {
			this.store.write(out);
			this.dept.write(out);

		}
		public void readFields(DataInput in) throws IOException {
			this.store.readFields(in);
			this.dept.readFields(in);
		}
		public int compareTo(CompositeGroupKey pop) {
			if (pop == null)
				return 0;
			int intcnt = store.compareTo(pop.store);
			if (intcnt != 0) {
				return intcnt;
			} else {
				return dept.compareTo(pop.dept);
			}
		}
		@Override
		public String toString() 
		{
			return store.toString() + ":" + dept.toString();
		}
	}

	public static class MapFortotalCount extends Mapper<LongWritable, Text, CompositeGroupKey, IntWritable>
	{
		/*IntWritable weekly_sale = new IntWritable();
		Text store = new Text();
		Text dept = new Text();
		CompositeGroupKey store_dept = new CompositeGroupKey();

		public void map(LongWritable key, Text value, Context context)throws IOException, InterruptedException 
		{
			String line = value.toString();
			String[] keyvalue = line.split(",");
			store.set(new Text(keyvalue[0]));
			dept.set(keyvalue[1]);
			weekly_sale.set(Integer.parseInt(keyvalue[3]));
			CompositeGroupKey store_dept = new CompositeGroupKey(store,dept);
			context.write(store_dept, weekly_sale);
		}
*/
		
		CompositeGroupKey salesKey = new CompositeGroupKey();
		Text storeText = new Text();
		Text deptText = new Text();
		IntWritable populat = new IntWritable();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
			String[] keyvalue = line.split(",");
			storeText.set(new Text(keyvalue[0]));
			deptText.set(keyvalue[1]);
			populat.set(Integer.parseInt(keyvalue[3]));
			CompositeGroupKey salesKey = new CompositeGroupKey(storeText, deptText);
			context.write(salesKey, populat);
		}
	}

	public static class ReduceJoin extends Reducer<CompositeGroupKey,IntWritable,CompositeGroupKey,IntWritable>{
		public void reduce(CompositeGroupKey key,Iterable<IntWritable> values,Context context) throws IOException, InterruptedException 
		{
			int sum = 0;
			for(IntWritable value : values){
				sum += value.get();
			}
			context.write(key , new IntWritable(sum));
		}
	}
	
	/*public static class ReducerJoin extends Reducer<CompositeGroupKey, IntWritable, CompositeGroupKey, IntWritable> {

		public void reduce(CompositeGroupKey key, Iterable<IntWritable> values, Context context) throws IOException,
		InterruptedException {
			int sum = 0;
			for(IntWritable value : values)
			{
				sum += value.get();
			}
			context.write(key, new IntWritable(sum));
		}
	}*/
}
