package com.EntityResolution.Dto;

public class AlgorithmDTO {

	private Long id;
	private String algorithmName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAlgorithmName() {
		return algorithmName;
	}
	public void setAlgorithmName(String algorithmName) {
		this.algorithmName = algorithmName;
	}
	
	

}
