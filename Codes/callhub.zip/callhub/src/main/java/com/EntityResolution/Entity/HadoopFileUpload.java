package com.EntityResolution.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hadoop_fileupload")
public class HadoopFileUpload {
	
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	@Column(name = "filename")
	private String filename ;
	
	@Column(name = "hdfspath")
	private String hdfspath ;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getHdfspath() {
		return hdfspath;
	}

	public void setHdfspath(String hdfspath) {
		this.hdfspath = hdfspath;
	}
	
	
	
	

}
