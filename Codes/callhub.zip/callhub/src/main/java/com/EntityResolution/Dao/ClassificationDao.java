package com.EntityResolution.Dao;

import java.util.List;

public interface ClassificationDao {
	
	public List<String> fetchClassificationInputPath() throws Exception;
	public List<String> fetchInputFilePath(String filename) throws Exception;

}
