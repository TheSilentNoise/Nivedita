package com.EntityResolution.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.EntityResolution.Dto.ClassificationDTO;
import com.EntityResolution.Service.ClassificationService;

@Controller
@RequestMapping("/Entity")
public class ClassificationController {
	
	@Autowired
	ClassificationService classificationService ;
	
	@RequestMapping(value = "/fetchClusterIpPortClassification" ,method = RequestMethod.POST)
	public @ResponseBody List<Object[]> fetchClusterIpPortClassification(@RequestBody String cluster) throws Exception{
		return classificationService.fetchClusterIpPortClassification(cluster);
	}
	
	@RequestMapping(value = "/fetchClassificationInputPath", method = RequestMethod.GET)
	public @ResponseBody List<String> fetchClassificationInputPath() throws Exception {	
		return classificationService.fetchClassificationInputPath();
	}
	
	@RequestMapping(value = "/fetchInputFilePath", method = RequestMethod.POST)
	public @ResponseBody List<String> fetchInputFilePath(@RequestBody String filename) throws Exception {	
		return classificationService.fetchInputFilePath(filename);
	}
	
	@RequestMapping(value = "/executeClassification", method = RequestMethod.POST)
	public @ResponseBody void executeClassification(@RequestBody ClassificationDTO  classificationDTO) throws Exception {	
		classificationService.executeClassification(classificationDTO);
	}

}
