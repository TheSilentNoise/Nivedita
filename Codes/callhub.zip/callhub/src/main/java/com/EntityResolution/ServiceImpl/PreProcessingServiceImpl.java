package com.EntityResolution.ServiceImpl;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.EntityResolution.Dao.EntityResolutionDao;
import com.EntityResolution.Dao.PreProcessingDao;
import com.EntityResolution.Dto.AddressSegmentationDTO;
import com.EntityResolution.Dto.ClusterDTO;
import com.EntityResolution.Entity.HadoopAddressSegmentation;
import com.EntityResolution.Service.PreProcessingService;
import com.EntityResolution.Util.ExecuteShellCommand;
import com.EntityResolution.Util.MergePartFile;

@Service
public class PreProcessingServiceImpl implements PreProcessingService{

	@Autowired 
	PreProcessingDao preProcessingDao;
	@Autowired
	EntityResolutionDao entityResolutionDao;
	
	ClusterDTO clusterDTO = new ClusterDTO();
	private static final String HADOOPUSER = "hduser";
	private String cluster ;
	@Override
	public List<Object[]> fetchMasterDetailsAddrs(String clusterName) throws Exception {
		List<Object[]> masterConfigDeatilsList = entityResolutionDao.fetchMasterDetails(clusterName);
		if(null !=masterConfigDeatilsList && masterConfigDeatilsList.size() >0 ){
			if(null != masterConfigDeatilsList.get(0)){
				Object[] obj = masterConfigDeatilsList.get(0);
				clusterDTO.setMasterIp((String)obj[0]);
				clusterDTO.setMasterPort((String)obj[1]);
			}
		}
		return masterConfigDeatilsList;
	}

	@Override
	public boolean saveAddressSegmentation(AddressSegmentationDTO addressSegmentationDTO) throws Exception {
		HadoopAddressSegmentation hadoopAddressSegmentation = new HadoopAddressSegmentation();
		hadoopAddressSegmentation.setFileName(addressSegmentationDTO.getFileName());
		hadoopAddressSegmentation.setInputfilepath(addressSegmentationDTO.getInputfilepath());
		hadoopAddressSegmentation.setAddressColIndex(addressSegmentationDTO.getAddressColIndex());
		hadoopAddressSegmentation.setOutputfilepath(addressSegmentationDTO.getOutputfilepath());
		hadoopAddressSegmentation.setDelimiter(addressSegmentationDTO.getDelimiter());
	return	preProcessingDao.saveAddressSegmentation(hadoopAddressSegmentation);
	}

	@Override
	public boolean executeAddressSegmentation(AddressSegmentationDTO addressSegmentationDTO) throws Exception{
		String command = "";
		String hadoopMaster = "hdfs://hadoop-master:54310";
		String sparknode = "spark://hadoop-master:7077" ;
		String filename = addressSegmentationDTO.getFileName() ;
		String inputfilepath = addressSegmentationDTO.getInputfilepath();
		String addressColIndex = addressSegmentationDTO.getAddressColIndex();
		String outputpath = addressSegmentationDTO.getOutputfilepath();
		String delimiter = addressSegmentationDTO.getDelimiter();
		command = "spark-submit address_segmentation.py ";
		command +=  hadoopMaster ;
		command  += inputfilepath + "/" +filename+ " " ;
		command +=  hadoopMaster + outputpath +"/"+filename + "_dir ";
		command += sparknode + " " + addressColIndex +" " + delimiter;	
		System.out.println(command);
		String user = "hduser";
		String password = "Admin123";
		String host = "172.18.100.103";
		int port=22;
		ExecuteShellCommand.executeCommand(user,password,host,port,command);
		TimeUnit.SECONDS.sleep(80);
		cluster = "hdfs://" + clusterDTO.getMasterIp() + ":" + clusterDTO.getMasterPort() ;
		boolean mergedFile = MergePartFile.mergeFile(cluster, HADOOPUSER, filename, outputpath);
		return mergedFile;
	}

}
