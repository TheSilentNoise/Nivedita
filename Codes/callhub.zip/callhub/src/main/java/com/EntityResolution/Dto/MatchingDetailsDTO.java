package com.EntityResolution.Dto;

public class MatchingDetailsDTO {
	
	private String columnNumber ;
	private String algorithmName ;
	
	public String getColumnNumber() {
		return columnNumber;
	}
	public void setColumnNumber(String columnNumber) {
		this.columnNumber = columnNumber;
	}
	public String getAlgorithmName() {
		return algorithmName;
	}
	public void setAlgorithmName(String algorithmName) {
		this.algorithmName = algorithmName;
	}

	
}
