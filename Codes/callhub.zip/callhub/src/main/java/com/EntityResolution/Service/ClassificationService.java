package com.EntityResolution.Service;

import java.util.List;

import com.EntityResolution.Dto.ClassificationDTO;

public interface ClassificationService {
	
	public List<Object[]> fetchClusterIpPortClassification(String cluster) throws Exception;
	public List<String> fetchClassificationInputPath() throws Exception;
	public List<String> fetchInputFilePath(String filename) throws Exception;
	public void executeClassification(ClassificationDTO  classificationDTO) throws Exception ;
	
	

}
