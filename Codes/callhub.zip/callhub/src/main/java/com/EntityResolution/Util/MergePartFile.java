package com.EntityResolution.Util;

import java.io.File;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
//need to add outputpath_dir in spark submit comand

public class MergePartFile {
	static boolean ismergesuccess = false;
	public static boolean mergeFile(String cluster ,String hduser,String filename,String outputpath){
		try {
			UserGroupInformation ugi = UserGroupInformation.createRemoteUser(hduser);
			ugi.doAs(new PrivilegedExceptionAction<Boolean>() {
				public Boolean run() throws Exception {
					Configuration conf = new Configuration();
					conf.set("fs.defaultFS", cluster);
					conf.set("hadoop.job.ugi", hduser);
					FileSystem fs = FileSystem.get(conf);
					// put file to hdfs
						System.out.println("hdcluster==="+cluster);
						String inputPath =  "/home/hadoop/Entity_Resolution/ER_AdrsSeg/"+filename ;
						File blankfile = new File(inputPath);
						blankfile.createNewFile();
						Path pathinput = new Path(inputPath);
						Path pathOutput = new Path(outputpath);
						Path successPath = new Path(pathOutput+"/"+filename+"_dir/_SUCCESS");
						Path subDirpath = new Path(pathOutput+"/"+filename+"_dir");
						fs.copyFromLocalFile(pathinput,subDirpath); 
						fs.delete(successPath, true);
						Path outputExists = new Path (outputpath+"/_SUCCESS");
						if(fs.exists(outputExists)){
							fs.delete(outputExists, true);
						}
					// merge file	
						String trg = cluster + outputpath +"/" + filename + "_dir/"+ filename;
						Path target = new Path(trg);
						List<Path> fileList = new ArrayList<Path>(); 
						FileStatus[] fstatus1 = fs.listStatus(new Path(outputpath+"/"+filename+"_dir"));
						for(int i=0;i<fstatus1.length;i++){
							if(fstatus1[i].getPath().equals(target) || fstatus1[i].isDirectory()){
								System.out.println("break...");
							}else{
								fileList.add(fstatus1[i].getPath());
								System.out.println(fstatus1[i].getPath());
							}
						}
						Path [] mergeFile = fileList.toArray(new Path[fileList.size()]);
						fs.concat(target, mergeFile);
						System.out.println("merging done..");
						fs.rename(target, pathOutput);
						if(fs.exists(subDirpath)){
							fs.delete(subDirpath, true);
						}						
					return ismergesuccess =true;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			return ismergesuccess =false;
		}
		return ismergesuccess;
	}
}
