package com.EntityResolution.Util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;

public class RowNumGenerator {
	public static boolean generateRowNum(String inputpath,String outputpath)
	{
		try {
			FileOutputStream fos = new FileOutputStream(new File(outputpath));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			BufferedReader br = new BufferedReader(new FileReader(inputpath));
		    String line;
		    Integer i=1;
		    File file=new File(inputpath);
		    while ((line = br.readLine()) != null) {
		    	line= file.getName()+"_"+i+","+line;
		    	 bw.write(line);
		    	 bw.newLine();
		    	 i++;
		    }
		    br.close();
		    bw.close();
		    return true;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
