package com.EntityResolution.Dto;

public class ClassificationPanel {
	
	private int id ;
	private String columnIndex ;
	private String columnName ;
	private String columnWeight ;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getColumnIndex() {
		return columnIndex;
	}
	public void setColumnIndex(String columnIndex) {
		this.columnIndex = columnIndex;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getColumnWeight() {
		return columnWeight;
	}
	public void setColumnWeight(String columnWeight) {
		this.columnWeight = columnWeight;
	}
	
	

}
