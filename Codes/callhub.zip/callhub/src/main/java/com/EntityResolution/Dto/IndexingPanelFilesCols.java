package com.EntityResolution.Dto;

public class IndexingPanelFilesCols {
	
	private int colID ;
	private String indexingCol ;
	private String indexingSubstr ;
	
	
	
	public int getColID() {
		return colID;
	}
	public void setColID(int colID) {
		this.colID = colID;
	}
	public String getIndexingCol() {
		return indexingCol;
	}
	public void setIndexingCol(String indexingCol) {
		this.indexingCol = indexingCol;
	}
	public String getIndexingSubstr() {
		return indexingSubstr;
	}
	public void setIndexingSubstr(String indexingSubstr) {
		this.indexingSubstr = indexingSubstr;
	}
		
	
	
}

