package com.EntityResolution.ServiceImpl;

import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.EntityResolution.Dao.EntityResolutionDao;
import com.EntityResolution.Dao.MatchingDao;
import com.EntityResolution.Dto.AlgorithmDTO;
import com.EntityResolution.Dto.ClusterDTO;
import com.EntityResolution.Dto.MatchingDTO;
import com.EntityResolution.Entity.HadoopAlgorithm;
import com.EntityResolution.Entity.HadoopMatching;
import com.EntityResolution.Service.MatchingService;
import com.EntityResolution.Util.ExecuteShellCommand;
import com.EntityResolution.Util.MergePartFile;

@Service
public class MatchingServiceImpl implements MatchingService{

	@Autowired 
	MatchingDao matchingDao ;
	
	@Autowired
	EntityResolutionDao entityResolutionDao;
	
	ClusterDTO clusterDTO = new ClusterDTO();
	private static final String HADOOPUSER = "hduser";
	private String cluster ;
	private String matchingoutputpath="";
	
	@Override
	public List<Object[]> fetchClusterIpPortMatching(String clusterName) throws Exception {
		List<Object[]> masterConfigDeatilsList = entityResolutionDao.fetchMasterDetails(clusterName);
		if(null !=masterConfigDeatilsList && masterConfigDeatilsList.size() >0 ){
			if(null != masterConfigDeatilsList.get(0)){
				Object[] obj = masterConfigDeatilsList.get(0);
				clusterDTO.setMasterIp((String)obj[0]);
				clusterDTO.setMasterPort((String)obj[1]);
			}
		}
		return masterConfigDeatilsList;
	}

	@Override
	public List<AlgorithmDTO> fetchAlgorithmName() throws Exception {
		List<AlgorithmDTO> algorithmDTOlist = new ArrayList<AlgorithmDTO>();
		List<HadoopAlgorithm> algorithmEntity =  matchingDao.fetchAlgorithmName();
		for (HadoopAlgorithm algorithm : algorithmEntity){
			AlgorithmDTO algorithmDTO = new AlgorithmDTO();
			algorithmDTO.setId(algorithm.getId());
			algorithmDTO.setAlgorithmName(algorithm.getAlgorithmName());
			algorithmDTOlist.add(algorithmDTO);
		}
		return algorithmDTOlist;
	}

	@Override
	public List<MatchingDTO> showFileDeleteList() throws Exception {
		List<MatchingDTO> matchingDTOlist = new ArrayList<MatchingDTO>();
		List<HadoopMatching> matchingEntity =  matchingDao.showFileDeleteList();
		for (HadoopMatching matching : matchingEntity){
			MatchingDTO matchingDTO = new MatchingDTO();
			matchingDTO.setFileName(matching.getFileName());
			matchingDTOlist.add(matchingDTO);
		}
		return matchingDTOlist;
	}

	@Override
	public List<HadoopMatching> saveAndShowMatchingData(MatchingDTO matchingDTO) throws Exception {
		String columnAlgoName = "";
		String fileName = matchingDTO.getFileName();
		String delimiter = matchingDTO.getDelimiter();
		String matchingInputPath = matchingDTO.getMatchingInputPath();
		String matchingOutputPath= matchingDTO.getMatchingOutputPath();
		for(int i=0;i<(matchingDTO.getMatchingDetailsDTO().size());i++){
			columnAlgoName = columnAlgoName +(matchingDTO.getMatchingDetailsDTO().get(i).getColumnNumber())+":"+(matchingDTO.getMatchingDetailsDTO().get(i).getAlgorithmName());
			if(i!=(matchingDTO.getMatchingDetailsDTO().size()-1)){
				columnAlgoName = columnAlgoName + ";" ;
			}	 
		}
		System.out.println("columnAlgo======="+columnAlgoName);
		HadoopMatching hadoopMatching = new HadoopMatching();
		hadoopMatching.setFileName(fileName);
		hadoopMatching.setDelimiter(delimiter);
		hadoopMatching.setColumnAlgoName(columnAlgoName);
		hadoopMatching.setMatchingInputPath(matchingInputPath);
		hadoopMatching.setMatchingOutputPath(matchingOutputPath);
		return  matchingDao.saveAndShowMatchingData(hadoopMatching);
	}

	@Override
	public List<MatchingDTO> deleteMatchingData(String filename) throws Exception {
		matchingDao.deleteMatchingData(filename);
		List<MatchingDTO> matchingDTOlist =  this.showFileDeleteList();
		return matchingDTOlist;	
	}

	@Override
	public void deleteHadoopDirectoryForMatching(List<HadoopMatching> hadoopMatchingList){
		System.setProperty("hadoop.home.dir", "D:\\HADOOP\\winutils\\");
		for(HadoopMatching hadoopMatching : hadoopMatchingList){
			matchingoutputpath = hadoopMatching.getMatchingOutputPath();
		}
		try {
			UserGroupInformation ugi = UserGroupInformation.createRemoteUser("hduser");
			ugi.doAs(new PrivilegedExceptionAction<Void>() {
				public Void run() throws Exception {
					Configuration conf = new Configuration();
					conf.set("fs.defaultFS", "hdfs://172.18.100.103:54310/");
					conf.set("hadoop.job.ugi", "hduser");
					FileSystem fs = FileSystem.get(conf);
					Path dest = new Path(matchingoutputpath);
					fs.delete(dest,true);
					System.out.println("Hadoop Directory Deleted Successfully For Matching");
					return null;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean executeSparkCommandForMatching(List<HadoopMatching> matchingList) throws InterruptedException{
		String filename="",columnAlgoName="",delimiter="",matchinputpath="",matchoutputpath="";
		for(HadoopMatching hadoopMatching : matchingList){
			filename=hadoopMatching.getFileName();
			columnAlgoName=hadoopMatching.getColumnAlgoName();
			delimiter = hadoopMatching.getDelimiter();
			matchinputpath = hadoopMatching.getMatchingInputPath();
			matchoutputpath = hadoopMatching.getMatchingOutputPath();
		}
		String hadoopMaster = "hdfs://hadoop-master:54310";
		matchinputpath = hadoopMaster+matchinputpath;
		String matchoutputpath_dummy = hadoopMaster+matchoutputpath+"/"+filename+"_dir ";
		String command = "spark-submit --master spark://hadoop-master:7077 ";
		command += "--class com.rs.Matching.MainObject EntityResolution_JARS/Entity_Resolution.jar"+" "+matchinputpath+"/part*"+" "+matchoutputpath_dummy;
		command += "\""+filename+"|"+columnAlgoName+"\"" +" "+delimiter;
		System.out.println(command);
		String user = "hduser";
		String password = "Admin123";
		String host = "172.18.100.103";
		int port=22;
		ExecuteShellCommand.executeCommand(user,password,host,port,command);
		TimeUnit.SECONDS.sleep(15);
		cluster = "hdfs://" + clusterDTO.getMasterIp() + ":" + clusterDTO.getMasterPort() ;
		boolean mergedFile = MergePartFile.mergeFile(cluster, HADOOPUSER, filename, matchoutputpath);
		return mergedFile;
	}

	@Override
	public boolean validateMatchingFile(String filename) throws Exception{
		return matchingDao.validateMatchingFile(filename);
	}

	@Override
	public List<String> fetchIndexingOutputPath() throws Exception{
		return  matchingDao.fetchIndexingOutputPath();
	}

}
