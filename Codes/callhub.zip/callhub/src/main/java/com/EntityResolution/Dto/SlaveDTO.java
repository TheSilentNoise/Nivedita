package com.EntityResolution.Dto;

public class SlaveDTO {

	private Long id;
	private String slaveIp;
	private String slavePort;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSlaveIp() {
		return slaveIp;
	}
	public void setSlaveIp(String slaveIp) {
		this.slaveIp = slaveIp;
	}
	public String getSlavePort() {
		return slavePort;
	}
	public void setSlavePort(String slavePort) {
		this.slavePort = slavePort;
	}

}
