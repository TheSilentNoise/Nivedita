package com.EntityResolution.Dto;

import java.util.ArrayList;
import java.util.List;

public class ClassificationDTO {


	private String classificationInputPath;
	private String classificationFilename;
	private String classificationOutputPath;
	private String inputFilePath ;
	private String noOfcols ;
	private List<ClassificationPanel>  classificationPanel = new ArrayList<ClassificationPanel>();

	public String getClassificationInputPath() {
		return classificationInputPath;
	}

	public void setClassificationInputPath(String classificationInputPath) {
		this.classificationInputPath = classificationInputPath;
	}

	public String getClassificationOutputPath() {
		return classificationOutputPath;
	}

	public void setClassificationOutputPath(String classificationOutputPath) {
		this.classificationOutputPath = classificationOutputPath;
	}

	public String getClassificationFilename() {
		return classificationFilename;
	}

	public void setClassificationFilename(String classificationFilename) {
		this.classificationFilename = classificationFilename;
	}

	public String getNoOfcols() {
		return noOfcols;
	}

	public void setNoOfcols(String noOfcols) {
		this.noOfcols = noOfcols;
	}

	public List<ClassificationPanel> getClassificationPanel() {
		return classificationPanel;
	}

	public void setClassificationPanel(List<ClassificationPanel> classificationPanel) {
		this.classificationPanel = classificationPanel;
	}

	public String getInputFilePath() {
		return inputFilePath;
	}

	public void setInputFilePath(String inputFilePath) {
		this.inputFilePath = inputFilePath;
	}




}
