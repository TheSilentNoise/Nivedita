package com.EntityResolution.ServiceImpl;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.security.PrivilegedExceptionAction;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.EntityResolution.Dao.ClassificationDao;
import com.EntityResolution.Dao.EntityResolutionDao;
import com.EntityResolution.Dto.ClassificationDTO;
import com.EntityResolution.Dto.ClusterDTO;
import com.EntityResolution.Service.ClassificationService;
import com.EntityResolution.Util.ExecuteShellCommand;
import com.EntityResolution.Util.MergePartFile;

@Service
public class ClassificationServiceImpl implements ClassificationService {

	@Autowired
	ClassificationDao classificationDao;
	
	@Autowired
	EntityResolutionDao entityResolutionDao;

	ClusterDTO clusterDTO = new ClusterDTO();
	private static final String HADOOPUSER = "hduser";
	private String cluster ;
	
	@Override
	public List<Object[]> fetchClusterIpPortClassification(String cluster) throws Exception {
		List<Object[]> masterConfigDeatilsList = entityResolutionDao.fetchMasterDetails(cluster);
		if(null !=masterConfigDeatilsList && masterConfigDeatilsList.size() >0 ){
			if(null != masterConfigDeatilsList.get(0)){
				Object[] obj = masterConfigDeatilsList.get(0);
				clusterDTO.setMasterIp((String)obj[0]);
				clusterDTO.setMasterPort((String)obj[1]);
			}
		}
		return masterConfigDeatilsList;
	}

	@Override
	public List<String> fetchClassificationInputPath() throws Exception {
		return classificationDao.fetchClassificationInputPath();
	}
	@Override
	public List<String> fetchInputFilePath(String filename) throws Exception {
		return classificationDao.fetchInputFilePath(filename);
	}

	@Override
	public void executeClassification(ClassificationDTO classificationDTO) throws Exception {
		String weightfilecontent = "";
		String columnIndex,columnName,columnWeight;
		String mathingoutputpath = classificationDTO.getClassificationInputPath();
		String classificationOutputpath = classificationDTO.getClassificationOutputPath();
		String matchingfilename = classificationDTO.getClassificationFilename();
		String inputfilepath = classificationDTO.getInputFilePath();
		String structuredmatchingfile = mathingoutputpath +"/" +matchingfilename ;
		
		for(int i=0;i<(classificationDTO.getClassificationPanel().size());i++){
			columnIndex = "_c"+(Integer.parseInt(classificationDTO.getClassificationPanel().get(i).getColumnIndex()) - 1);
			columnName = classificationDTO.getClassificationPanel().get(i).getColumnName();
			columnWeight = classificationDTO.getClassificationPanel().get(i).getColumnWeight();
			weightfilecontent += columnIndex + "," + columnName + "," + columnWeight + "\n" ;
		}

		String columnWeightFile = "/home/hadoop/Entity_Resolution/ER_classificationFiles/weightfile.txt";
		BufferedWriter bw = new BufferedWriter(new FileWriter(columnWeightFile));
		bw.write(weightfilecontent);
		bw.close();

		Path columnWeightFilelocal = new Path(columnWeightFile);
		Path columnWeightFileHdfs = new Path("/affinity/ColumnWeightV9.csv");

		Path structuredMatchingFilehdfs = new Path(structuredmatchingfile);
		Path structuredMatchingFileremotehdfs = new Path("/affinity/StructredOutputDataV11.csv");

		try {
			UserGroupInformation ugi = UserGroupInformation.createRemoteUser(HADOOPUSER);
			ugi.doAs(new PrivilegedExceptionAction<Void>() {	
				public Void run() throws Exception {

					Configuration conf1 = new Configuration();
					String cluster1 = "hdfs://172.18.19.155:54310" ;
					conf1.set("fs.defaultFS", cluster1);
					conf1.set("hadoop.job.ugi", "hduser");
					FileSystem fs1 = FileSystem.get(conf1);

					Configuration conf2 = new Configuration();
					String cluster2 ="hdfs://" + clusterDTO.getMasterIp() + ":" + clusterDTO.getMasterPort();
					conf2.set("fs.defaultFS", cluster2);
					conf2.set("hadoop.job.ugi", "hduser");
					FileSystem fs2 = FileSystem.get(conf2);

					FileUtil.copy(fs2,structuredMatchingFilehdfs,fs1,structuredMatchingFileremotehdfs,false,conf2);

					if(fs1.exists(columnWeightFileHdfs) ){
						fs1.delete(columnWeightFileHdfs,true);
						fs1.copyFromLocalFile(columnWeightFilelocal, columnWeightFileHdfs);
					}else{
						fs1.copyFromLocalFile(columnWeightFilelocal, columnWeightFileHdfs);
					}
					String classificationScript = "sh /home/hduser/runRSpark.sh" ;
					String user = "hduser" ;
					String password = "Admin123" ;
					String host1 = "172.18.19.155" ;
					int port = 22;
					ExecuteShellCommand.executeCommand(user, password, host1, port, classificationScript);
					TimeUnit.SECONDS.sleep(200);

					//deduplication

					fs2.delete(new Path("/ER/UniqueRecord"), true);
					fs2.mkdirs(new Path("/ER/UniqueRecord"));
					fs2.copyFromLocalFile(new Path("/home/hadoop/Entity_Resolution/ER_classificationFiles/classification_output/structuredOp.txt"),new Path("/ER/UniqueRecord/"));
					String deduplicationScript = "spark-submit --master spark://hadoop-master:7077 --class com.rs.Deduplication.UniqueRecordGenerate "
							+ "EntityResolution_JARS/Entity_Resolution.jar hdfs://hadoop-master:54310/ER/UniqueRecord/structuredOp.txt "
							+ "hdfs://hadoop-master:54310"+inputfilepath+"/"+matchingfilename
							+ " hdfs://hadoop-master:54310" + classificationOutputpath +"/"+matchingfilename + "_dir " ;
					String host2 = "172.18.100.103" ;
					System.out.println(deduplicationScript);
					ExecuteShellCommand.executeCommand(user, password, host2, port, deduplicationScript);
					TimeUnit.SECONDS.sleep(50);
					cluster = "hdfs://" + clusterDTO.getMasterIp() + ":" + clusterDTO.getMasterPort() ;
					MergePartFile.mergeFile(cluster, HADOOPUSER, matchingfilename, classificationOutputpath);
					System.out.println(" Classification Done..........................");
					return null;
				}
			});
		} 
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	


	

	
}
