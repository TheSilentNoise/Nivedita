myApp.controller('classificationcontroller', function($scope,$http,$window){

	$http.get(restContextpath+"/Entity/fetchClusterNames").then(function(response) {
		$scope.clusterDropdown = [];
		if(response.status == 200){
			$scope.clusterDropdown = response.data;
		}else{
			alert("Something wrong from server.");
		}
	});

	$scope.selectCluster = function(){
		var request1 = $http({
			method: 'POST',
			data:$scope.selectedCluster ,
			url: restContextpath+"/Entity/fetchClusterIpPort",
		});
		request1.success(function(data){
		});
		request1.error(function(data){
		});
		
		var request2 = $http({
			method: 'POST',
			data:$scope.selectedCluster ,
			url: restContextpath+"/Entity/fetchClusterIpPortClassification",
		});
		request2.success(function(data){
		});
		request2.error(function(data){
		});
		
	}

	$http.get(restContextpath+"/Entity/fetchClassificationInputPath").then(function(response) {
		$scope.classfInputpathDropdowns = [];
		if(response.status == 200){
			$scope.classfInputpathDropdowns = response.data;
		}else{
			alert("Something wrong from server.");
		}
	});

	$scope.viewHdfsFileList = function(){
		if($scope.selectedCluster == "" || $scope.selectedCluster == null){
			alert("Please select the Cluster!");
		}else{
			var request = $http({
				method: 'POST',
				url: restContextpath+"/Entity/viewHDFSFileList",
				data: $scope.classificationDTO.classificationInputPath ,
				contentType: "application/json",
				headers: { 
					'Accept': 'application/json',
					'Content-Type': 'application/json' 
				},
			});
			request.success(function(data){
				$scope.classificationfileDropdown=[];
				data.forEach(function(obj){
					if(obj.name!=null){
						$scope.classificationfileDropdown.push(obj.name);
					}
				});
			});
			request.error(function(data){
				alert("Something wrong!!");
			});
		}
	}
	
	$scope.viewClassificationFileContent = function(){
		$scope.filepath = $scope.classificationDTO.classificationInputPath + "/" + $scope.classificationDTO.classificationFilename ;
		var request = $http({
			method: 'POST',
			url: restContextpath+"/Entity/viewHDFSFileContent",
			data: $scope.filepath,
			headers: { 
				'Accept': 'application/text',
				'Content-Type': 'application/text' 
			},
			ContentType: 'application/text'
		});
		request.success(function(data){
			$scope.txtclassificationFilecontent = data ;
		});
		request.error(function(data){
			alert("Something wrong!!");
		});
	}
	
	$scope.populateinputfiledropdown = function(){
			var request = $http({
				method: 'POST',
				url: restContextpath+"/Entity/fetchInputFilePath",
				data: $scope.classificationDTO.classificationFilename ,
				contentType: "application/json",
				headers: { 
					'Accept': 'application/json',
					'Content-Type': 'application/json' 
				},
			});
			request.success(function(data){
				$scope.inputfileDropdown=[];
				data.forEach(function(obj){
					if(obj!=null){
						$scope.inputfileDropdown.push(obj);
					}
				});
			});
			request.error(function(data){
				alert("Something wrong!!");
			});
	}

	$scope.addClassificationPanel = function(){
		$scope.classificationDTO.classificationPanel = [];
		if($scope.classificationDTO.noOfcols){
			for(var i = 1; i<=$scope.classificationDTO.noOfcols; i++){
				$scope.classificationDTO.classificationPanel.push({id:i,columnIndex:"",columnName:"",columnWeight:""});
			}
		}
	}

	$scope.classificationDTO = {};
	$scope.classificationDTO.classificationPanel = [];

	$scope.submitClassification = function(){
		var totalweight = 0 ;
		var panelArr = $scope.classificationDTO.classificationPanel;
		panelArr.forEach(function(obj){
			totalweight += parseFloat(obj.columnWeight);
		});
		if(totalweight !== 1 ){
			alert("Total columnweight should be 1");
		}
		else{
			$(".page-loader").show();
			var request = $http({
				method: 'POST',
				url: restContextpath+"/Entity/executeClassification",
				data: $scope.classificationDTO,
				headers: { 
					'Accept': 'application/json',
					'Content-Type': 'application/json' 
				},
				ContentType: 'application/json'
			});
			request.success(function(data){
				$(".page-loader").hide();
				alert("Classification execution completed..!!");
			});
			request.error(function(data){
				$(".page-loader").hide();
				alert("Something wrong!!");
			});
		}
	}
});