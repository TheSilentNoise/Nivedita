package com.rs.MerchantInfo.Util;

public interface CommonConstant {
	
	public static String TRANSPORT_ADDRESS = "172.18.100.102" ;
	public static String INDEX_NAME = "merchant" ;
	public static String TYPE_NAME = "dbsourcein" ;	

}
