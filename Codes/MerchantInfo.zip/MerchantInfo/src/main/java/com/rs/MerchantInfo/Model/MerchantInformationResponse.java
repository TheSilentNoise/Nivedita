package com.rs.MerchantInfo.Model;

public class MerchantInformationResponse {
	
	private String cin;
	private String merchantName ;
	private String merchantAddress ;
	private String status ;
	private String companyClass ;
	private String dateofRegistration;
	private String emailId ;
	private double score ;
	
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantAddress() {
		return merchantAddress;
	}
	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getCompanyClass() {
		return companyClass;
	}
	public void setCompanyClass(String companyClass) {
		this.companyClass = companyClass;
	}
	public String getDateofRegistration() {
		return dateofRegistration;
	}
	public void setDateofRegistration(String dateofRegistration) {
		this.dateofRegistration = dateofRegistration;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	

}
