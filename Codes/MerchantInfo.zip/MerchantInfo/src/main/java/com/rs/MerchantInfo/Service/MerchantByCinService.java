package com.rs.MerchantInfo.Service;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import com.rs.MerchantInfo.Model.MerchantByCinRequest;
import com.rs.MerchantInfo.Model.MerchantInformationResponse;
import com.rs.MerchantInfo.Util.CommonConstant;

@Service
public class MerchantByCinService {

	@SuppressWarnings("resource")
	public List<MerchantInformationResponse> merchantByCinService(MerchantByCinRequest merchantByCinRequest) {
		List<MerchantInformationResponse> MerchantAddressResponselist = new ArrayList<MerchantInformationResponse>();

		String input_cin = merchantByCinRequest.getCin();

		TransportClient client = null;
		
		try {
			client = new PreBuiltTransportClient(Settings.EMPTY)
					.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(CommonConstant.TRANSPORT_ADDRESS), 9300));

			String queryString = "{\"bool\": { \"must\": [ { \"match\": { \"CIN\": {\"query\": \""+input_cin+"\" }}}]}}";

			SearchRequestBuilder searchRequestBuilder;
			searchRequestBuilder = client.prepareSearch(CommonConstant.INDEX_NAME).setTypes(CommonConstant.TYPE_NAME);
			searchRequestBuilder.setQuery(QueryBuilders.wrapperQuery(queryString));
			SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();

			String hitsobjJson = searchResponse.toString();	

			System.out.print(hitsobjJson);

			JSONObject obj = new JSONObject(hitsobjJson);
			JSONObject jsonChildObject = (JSONObject)obj.get("hits");
			JSONArray hitsarr = jsonChildObject.getJSONArray("hits");
			
			int count = 0;
			if(hitsarr.length()!=0){
				for (int i = 0; i < hitsarr.length(); i++){
					count+=1;
					if(count<=5){
						
						String indexString =hitsarr.get(i).toString();
						JSONObject obj1 = new JSONObject(indexString);
						double score = obj1.getDouble("_score");
						JSONObject jsonChild = (JSONObject)obj1.get("_source");

						String merchant_name = jsonChild.getString("COMPANY_NAME");
						String merchant_address = jsonChild.getString("ADDRESS");
						String status = jsonChild.getString("STATUS");
						String cin = jsonChild.getString("CIN");
						String companyClass = jsonChild.getString("COMPANY_CLASS");
						String dateofRegistration = jsonChild.getString("DATE_OF_REGISTRATION");
						String emailId = jsonChild.getString("EMAIL_ID");

						MerchantInformationResponse merchantAddressResponse = new MerchantInformationResponse();
						merchantAddressResponse.setCin(cin);
						merchantAddressResponse.setMerchantName(merchant_name);
						merchantAddressResponse.setMerchantAddress(merchant_address);
						merchantAddressResponse.setStatus(status);
						merchantAddressResponse.setScore(score);
						merchantAddressResponse.setCompanyClass(companyClass);
						merchantAddressResponse.setDateofRegistration(dateofRegistration);
						merchantAddressResponse.setEmailId(emailId);
						MerchantAddressResponselist.add(merchantAddressResponse);
						
					}else{
						break;
					}
				}
				client.close();
			}else{
			    client.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			client.close();
		}

		return MerchantAddressResponselist;
	}
	
	

}
