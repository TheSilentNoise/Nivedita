package com.rs.MerchantInfo.Model;

public class MerchantByCinRequest {
	
	private String cin ;

	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}
	
	

}
