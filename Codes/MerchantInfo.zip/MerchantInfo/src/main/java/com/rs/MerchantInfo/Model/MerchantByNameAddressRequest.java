package com.rs.MerchantInfo.Model;

public class MerchantByNameAddressRequest {
	
	private String merchantName ;
	private String merchantAddress ;
	
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantAddress() {
		return merchantAddress;
	}
	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}
	
	

}
