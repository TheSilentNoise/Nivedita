package com.rs.MerchantInfo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.rs.MerchantInfo.Model.MerchantByCinRequest;
import com.rs.MerchantInfo.Model.MerchantByNameAddressRequest;
import com.rs.MerchantInfo.Model.MerchantInformationResponse;
import com.rs.MerchantInfo.Service.MerchantByCinService;
import com.rs.MerchantInfo.Service.MerchantByNameAddressService;

@Controller
public class MerchantInfoController {
	
	@Autowired
	MerchantByNameAddressService merchantByNameAddressService;
	
	@Autowired
	MerchantByCinService merchantByCinService ;
	
	@RequestMapping(value = "/getMerchantByAddress", method = RequestMethod.POST )
	public @ResponseBody List<MerchantInformationResponse> getMerchantByAddress(@RequestBody MerchantByNameAddressRequest merchantAddressRequest){
		return merchantByNameAddressService.getMerchantByAddress(merchantAddressRequest);
	}
	
	@RequestMapping(value = "/getMerchantByCin", method = RequestMethod.POST )
	public @ResponseBody List<MerchantInformationResponse> getMerchantByCin(@RequestBody MerchantByCinRequest merchantByCinRequest){
		return merchantByCinService.merchantByCinService(merchantByCinRequest);
	}
	

}
