var myApp = angular.module('myApp',[]);

var restContextpath="/LoanDefaultPredictor";

myApp.controller('dmaController', function($scope,$http,$window){


//	****************************************************** Upload File ****************************************************

	$scope.fileName = "";
	$scope.username=NAME_STR;
	$scope.inputpath = "/home/hadoop/Loan_Defaulter_Prediction/WebLoan/"+$scope.username+"/";
	
	console.log($scope.inputpath);

	$scope.uploadFile = function(el, event){
		var filepath = document.getElementById("singlefile").value;
		$scope.fileName = filepath.split('/').pop().split('\\').pop();
		if($scope.fileName.includes(' ')){
			$scope.fileName = $scope.fileName.replace(/\s+/g,'_');
		}
		$.ajax({
			url: restContextpath+"/uploadfile",
			type: "POST",
			data:new FormData(document.getElementById("uploadform")),
			enctype: 'multipart/form-data',
			processData: false,
			contentType: false
		}).done(function(data){
			if(data){
				var path = $scope.inputpath+"Encrypted"+"/"+$scope.fileName;
				$scope.viewhdfsinputfilecontent(path);
				console.log(path);
			}
			else{
				alert('File not uploaded ...');
			}
		}).fail(function(jqXHR, textStatus) {
			alert('File upload failed ...');
		});
	}

//	***************************************************** view file content ********************************************		

	$scope.viewhdfsinputfilecontent = function(filepath){
		var request = $http({
			method: 'POST',
			url: restContextpath+"/viewFileContent",
			data: filepath,
			headers: { 
				'Accept': 'application/text',
				'Content-Type': 'application/text' 
			},
			ContentType: 'application/text'
		});
		var counts=0;
		request.success(function(data){

			if($("#inputTable").find('tr').length>0){
				$('#inputTable').DataTable().destroy();
			}
			$('#inputTable').html("");

			var myEl = angular.element( document.querySelector('#inputTable'));
			myEl.html('');
			var theadrow=""
				var row="";
			var thead="";
			for(i = 0 ;i< data.split("\n").length ; i++){
				var td="";
				thead="";
				json = data.split("\n")[i] ;
				for(j=0;j<json.split(",").length;j++){
					tblJson = json.split(",")[j];
					if(i==0){
						counts=0;
						td+="<th>"+tblJson+"</th>";
					}else{
						counts=1;
						td+="<td>"+tblJson+"</td>";
					}
				}
				if(counts==0){
					theadrow='<tr>'+td+'</tr>';
				}else{
					row+='<tr>'+td+'</tr>';
				}
			}
			myEl.append('<thead>'+theadrow+'</thead>');
			myEl.append('<tbody>'+row+'</tobdy>');
			$('#inputTable tbody tr:last-child').remove();
			$('#inputTable').DataTable({
				"destroy": true, 
				//"lengthMenu": [[5,10,25,50,-1], [5,10,25,50,"All"]],
			});
		});
		request.error(function(data){
			alert("Something wrong!!");
		});
	}

//	******************************************************** Execute service engine ********************************************

	$scope.executeERservice = function(){
		var path = $scope.inputpath+"Decrypted/"+$scope.fileName;
		var request = $http({
			method: 'POST',
			url: restContextpath+"/execute",
			data: path,
			headers: { 
				'Accept': 'application/json',
				'Content-Type': 'application/json' 
			},
			ContentType: 'application/json'
		});
		request.success(function(data){
			if(data==true){
				$scope.isShowOutputBox = true;
				var path = $scope.inputpath+"Output/"+$scope.fileName;
				$scope.viewoutputfilecontent(path);
				$scope.viewpredictiongraph(path);
			}else{
				alert("Something wrong!!");
			}
		});
		request.error(function(data){
			alert("Something wrong!!");
		});
	}

//	***************************************************** view output file **************************************************	

	$scope.viewoutputfilecontent = function(path){
		var request = $http({
			method: 'POST',
			url: restContextpath+"/viewOutputFileContent",
			data: path,
			headers: { 
				'Accept': 'application/text',
				'Content-Type': 'application/text' 
			},
			ContentType: 'application/text'
		});
		request.success(function(data){
			if($("#outputTable").find('tr').length>0){
				$('#outputTable').DataTable().destroy();
			}
			$('#outputTable').html("");

			var myEl = angular.element( document.querySelector('#outputTable'));
			myEl.html('');
			var theadrow=""
				var row="";
			var thead="";
			for(i = 0 ;i< data.split("\n").length ; i++){
				var td="";
				thead="";
				json = data.split("\n")[i] ;
				for(j=0;j<json.split(",").length;j++){
					tblJson = json.split(",")[j];
					if(i==0){
						counts=0;
						td+="<th>"+tblJson+"</th>";
					}else{
						counts=1;
						td+="<td>"+tblJson+"</td>";
					}
				}
				if(counts==0){
					theadrow='<tr>'+td+'</tr>';
				}else{
					row+='<tr>'+td+'</tr>';
				}
			}
			myEl.append('<thead>'+theadrow+'</thead>');
			myEl.append('<tbody>'+row+'</tobdy>');
			$('#outputTable tbody tr:last-child').remove();
			$('#outputTable').DataTable({
				"destroy": true, 
			});
		});
		request.error(function(data){
			alert("Something wrong!!");
		});
	}

//	************************************************* loan prediction graph **************************************************


	$scope.viewpredictiongraph = function(path){
		var request = $http({
			method: 'POST',
			url: restContextpath+"/getgraphdata",
			data: path,
			headers: { 
				'Accept': 'application/json',
				'Content-Type': 'application/json' 
			},
			ContentType: 'application/json'
		});
		request.success(function(data){
			var data = {
					labels: ["0-9%","10-19%","20-29%","30-39%","40-49%","50-59%","60-69%","70-79%","80-89%","90-100%"],
					datasets: [{
						label: "Reject",
						backgroundColor: "#ff9999",
						data: data.defaultvaluearr
					}, {
						label: "Approve",
						backgroundColor: "#99b3ff",
						data: data.nondefaultvaluearr
					}
					]
			};

			var ctx = document.getElementById("myChart2").getContext("2d");
			var myBarChart = new Chart(ctx, {
				type: 'bar',
				responsive:true,
				maintainAspectRatio: false,
				data: data,
				options: {
					barValueSpacing: 20,
					scales: {
						yAxes: [{ ticks: { min: 0,}}]
					}
				}
			});
		});
	}

});//end