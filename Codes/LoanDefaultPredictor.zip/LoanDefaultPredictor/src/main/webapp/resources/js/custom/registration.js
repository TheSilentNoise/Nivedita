var myApp = angular.module('myApp',[]);

var restContextpath="/LoanDefaultPredictor";

myApp.controller('dmaController', function($scope,$http,$window){

//	**************************************  User Registration **************************************************//		

	$scope.msg="";

	$scope.doRegisterUser = function(){
		if($scope.userDetails){
			if(!$scope.userDetails.organization_name){
				$scope.msg="Please provide your Organization Name ";
			}else if(!$scope.userDetails.email){
				$scope.msg="Please provide Email ";
			}else if(!$scope.userDetails.email.match("@")){
				$scope.msg="Please provide valid email id ";
			}else if(!$scope.userDetails.username){
				$scope.msg="Please provide username ";
			}else if(!$scope.userDetails.password){
				$scope.msg="Please provide password ";
			}else if(!$scope.userDetails.confirm_password){
				$scope.msg="Please provide confirm password ";
			}else if($scope.userDetails.password.length <6 || $scope.userDetails.confirm_password.length < 6){
				$scope.msg="Password should be atleast 6 character long";
			}else if ($scope.userDetails.password != $scope.userDetails.confirm_password){
				$scope.msg="Password don't match";
			}else{
				var request = $http({
					method: 'POST',
					url: restContextpath+"/registerUser",
					data: JSON.stringify($scope.userDetails),
					headers: { 
						'Accept': 'application/json',
						'Content-Type': 'application/json' 
					},
					ContentType: 'application/json'
				});
				request.success(function(data){
					if(data == true){
						alert("Registration is successful! Please remember your Username to login.");
						$window.location.href = restContextpath+"/";
					}
					else{
						$scope.msg="Username is already exists! Please try again with another!";
					}
				});
				request.error(function(data){
					alert("Something went wrong!");
				});
			}
		}
		else{
			$scope.msg="Please provide the credentials to Register";
		}
	}
	
});