package com.LoanDefaultPredictor.Controller;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.LoanDefaultPredictor.DTO.LoanGraphDTO;
import com.LoanDefaultPredictor.Entity.User;
import com.LoanDefaultPredictor.Entity.User_Roles;
import com.LoanDefaultPredictor.Service.LoanPredictService;

@RestController
public class LoanPredictionController {

	@Autowired
	LoanPredictService loanPredictService ;

	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public  boolean registerUser(@RequestBody User userDetails) throws Exception {

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String password = passwordEncoder.encode(userDetails.getPassword());
		String cnfpassword = passwordEncoder.encode(userDetails.getConfirm_password());
		Timestamp created_time = new Timestamp(System.currentTimeMillis());
		userDetails.setCreated_time(created_time.toString());
		userDetails.setEnabled(1);
		userDetails.setConfirm_password(cnfpassword);
		userDetails.setPassword(password);
		boolean saveUserData = loanPredictService.saveUserRegistration(userDetails);
		if(saveUserData){
			loanPredictService.createuserdirectory(userDetails.getUsername());
			User_Roles user_Roles = new User_Roles();
			user_Roles.setUsername(userDetails.getUsername());
			user_Roles.setRole("ROLE_USER");
			return loanPredictService.saveUserRoleData(user_Roles);
		}
		else{
			return false;
		}
	}

	
	@RequestMapping(value = "/uploadfile", method = RequestMethod.POST, headers = "Accept=application/json")  
	public boolean uploadfile(@RequestParam("file") MultipartFile file , @RequestParam("username") String username) throws Exception { 
		return loanPredictService.uploadfile(file,username);
	}

	@RequestMapping(value = "/viewFileContent" ,method = RequestMethod.POST)
	public String viewHDFSFileContent(@RequestBody String filepath) throws Exception{
		return loanPredictService.viewFileContent(filepath);
	}

	@RequestMapping(value = "/execute" ,method = RequestMethod.POST)
	public boolean execute(@RequestBody String filepath) throws Exception{
		//	return loanPredictService.execute(filepath);
		return true;
	}
	@RequestMapping(value = "/viewOutputFileContent" ,method = RequestMethod.POST)
	public String viewOutputFileContent(@RequestBody String filepath) throws Exception{
		return loanPredictService.viewOutputFileContent(filepath);
	}

	@RequestMapping(value = "/getgraphdata" ,method = RequestMethod.POST)
	public LoanGraphDTO getgraphdata(@RequestBody String filepath) throws Exception{
		return loanPredictService.getgraphdata(filepath);
	}
	
	@RequestMapping(value = "/downloadFile",method = RequestMethod.GET)
	public Object doDownload(@RequestParam("dlfile") String fileName,@RequestParam("username") String username,HttpServletRequest request,HttpServletResponse response) throws Exception { 
		return loanPredictService.doDownload(request, response,fileName,username);
	}

}
