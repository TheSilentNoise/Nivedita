package com.LoanDefaultPredictor.Service;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.LoanDefaultPredictor.DTO.LoanGraphDTO;
import com.LoanDefaultPredictor.Entity.User;
import com.LoanDefaultPredictor.Entity.User_Roles;


public interface LoanPredictService {

	boolean uploadfile(MultipartFile file, String username);
	String viewFileContent(String filepath) throws Exception;
	boolean execute(String filepath);
	boolean saveUserRegistration(User userDetails);
	void createuserdirectory(String username);
	String viewOutputFileContent(String filepath) throws IOException;
	LoanGraphDTO getgraphdata(String filepath);
	boolean saveUserRoleData(User_Roles user_Roles);
	Object doDownload(HttpServletRequest request, HttpServletResponse response, String fileName,String username) throws FileNotFoundException, IOException;

}
