package com.LoanDefaultPredictor.DaoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.LoanDefaultPredictor.Dao.LoanPredictDAO;
import com.LoanDefaultPredictor.Entity.User;
import com.LoanDefaultPredictor.Entity.User_Roles;

@Repository
public class LoanPredictDaoImpl implements LoanPredictDAO{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public boolean saveUserRegistration(User userDetails) {
		boolean isSuccess = false;
		Transaction tx = null;
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(userDetails);
			tx.commit();
			isSuccess = true;
		} catch (Exception e) {
			isSuccess = false;
			e.printStackTrace();
		} finally {
			session.close();
		}
		return isSuccess;
	}


	@Override
	public boolean saveUserRoleData(User_Roles user_Roles) {
		boolean isSuccess = false;
		Transaction tx = null;
		Session session = null;
		try {
			session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(user_Roles);
			tx.commit();
			isSuccess = true;
		} catch (Exception e) {
			isSuccess = false;
			e.printStackTrace();
		} finally {
			session.close();
		}
		return isSuccess;
	}

}
