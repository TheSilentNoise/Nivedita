package com.LoanDefaultPredictor.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class User implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	public User() {
		
	}
	
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "userid")
	private String userid;
		
	@Column(name = "username")
	private String username;
	
	@Column(name = "organization_name")
	private String organization_name;
		
	@Column(name = "password")
	private String password;
	
	@Column(name = "confirm_password")
	private String confirm_password;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "enabled")
	private int enabled;
	
	@Column(name = "created_time")
	private String created_time;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getOrganization_name() {
		return organization_name;
	}

	public void setOrganization_name(String organization_name) {
		this.organization_name = organization_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}
	
	
	
	
	
	

}
