package com.LoanDefaultPredictor.Util;

public interface CommonConstant {
	
	public static final String FILELOCATION = "/home/hadoop/Loan_Defaulter_Prediction/WebLoan/";
	
	static final byte[] KEY = { 0x74, 0x68, 0x69, 0x73, 0x49, 0x73, 0x41, 0x53, 0x65, 0x63, 0x72, 0x65, 0x74, 0x4b, 0x65, 0x79 };

	public static final int BUFFER_SIZE = 4096;
}
