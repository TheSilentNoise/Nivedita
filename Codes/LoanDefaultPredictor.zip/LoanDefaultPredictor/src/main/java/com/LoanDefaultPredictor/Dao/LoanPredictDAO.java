package com.LoanDefaultPredictor.Dao;

import com.LoanDefaultPredictor.Entity.User;
import com.LoanDefaultPredictor.Entity.User_Roles;

public interface LoanPredictDAO {

	boolean saveUserRegistration(User userDetails);
	boolean saveUserRoleData(User_Roles user_Roles);

}
