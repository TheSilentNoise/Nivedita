package com.LoanDefaultPredictor.ServiceImpl;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLConnection;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.LoanDefaultPredictor.DTO.LoanGraphDTO;
import com.LoanDefaultPredictor.Dao.LoanPredictDAO;
import com.LoanDefaultPredictor.Entity.User;
import com.LoanDefaultPredictor.Entity.User_Roles;
import com.LoanDefaultPredictor.Service.LoanPredictService;
import com.LoanDefaultPredictor.Util.CommonConstant;
import com.LoanDefaultPredictor.Util.Encryption;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


@Service
public class LoanPredictServiceImpl implements LoanPredictService{

	@Autowired
	LoanPredictDAO loanPredictDAO;

	@Override
	public boolean saveUserRegistration(User userDetails) {
		return loanPredictDAO.saveUserRegistration(userDetails);
	}
	
	@Override
	public boolean saveUserRoleData(User_Roles user_Roles) {
		return loanPredictDAO.saveUserRoleData(user_Roles);
	}
	
	@Override
	public void createuserdirectory(String username) {
		try{
			File dir = new File(CommonConstant.FILELOCATION+username);
			if (!dir.exists()){
				dir.mkdirs();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	@Override
	public boolean uploadfile(MultipartFile file,String username) {
		boolean fileUploadSuccess = false; 
		String filename = file.getOriginalFilename();

		if(filename.contains(" ")){
			filename = filename.replaceAll("\\s+","_");
		}
		try {
			byte[] bytes = file.getBytes();
			byte[] enbytes = Encryption.encryptBytesAndBase64Encode(bytes);

			String uploadpath = CommonConstant.FILELOCATION+username+"/Encrypted";
			
			System.out.println(uploadpath);

			File dir1 = new File(uploadpath);
			if (!dir1.exists()){
				dir1.mkdirs();
			}
			File serverFile = new File(dir1.getAbsolutePath()+ File.separator + filename);
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
			stream.write(enbytes);
			stream.close();
			fileUploadSuccess = true; 
		}
		catch(Exception ex){
			ex.printStackTrace();
			fileUploadSuccess = false; 
		}
		return fileUploadSuccess;
	}

	@Override
	public String viewFileContent(String filepath) throws Exception {

		String sCurrentLine = "";
		String output = "" ;
		// Decryption of file 
		try{	
			File encryptedFile = new File(filepath);
			FileInputStream inputStream = new FileInputStream(encryptedFile);
			byte[] inputBytes = new byte[(int) encryptedFile.length()];
			inputStream.read(inputBytes);
			byte[] outputBytes = Encryption.base64decodeAndDecryptBytes(inputBytes);

			String filename = encryptedFile.getName();
			String username = filepath.split("/")[5];
			String decryptedFileLocation = CommonConstant.FILELOCATION +username+"/Decrypted/";

			File dir = new File(decryptedFileLocation);
			if (!dir.exists()){
				dir.mkdirs();
			}
			File decryptedFile = new File (decryptedFileLocation+filename);
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(decryptedFile));
			stream.write(outputBytes);
			stream.close();

			//File read
			BufferedReader br = new BufferedReader(new FileReader(decryptedFileLocation+filename));
			while ((sCurrentLine = br.readLine()) != null) {
				output += sCurrentLine + "\n" ;
			}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return output;
	}

	@Override
	public boolean execute(String filepath) {
		
		String inputpath = filepath ;
		
		String username = filepath.split("/")[5];
		String outputdir = CommonConstant.FILELOCATION +username+"/Output/";
		
		String filename = filepath.split("/")[7];

		File dir = new File(outputdir);
		if (!dir.exists()){
			dir.mkdirs();
		}
		
		String outputpath = outputdir+filename;
		
		String scriptFileName = "Rscript /home/hadoop/Loan_Defaulter_Prediction/WebLoan/Random_Forest_Loan_Prediction.R "+inputpath + " "+outputpath;
		
		String USERNAME ="hadoop"; 
		String PASSWORD ="Admin123"; 
		String host = "172.18.100.102"; 
		int port=22;
		boolean isSuccessstatus = false;
		Session session ;
		ChannelExec channelExec;
		try{
			JSch jsch = new JSch();
			session = jsch.getSession(USERNAME, host, port);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(PASSWORD);
			session.connect();
			System.out.println("connected...");
			channelExec = (ChannelExec)session.openChannel("exec");
			channelExec.getInputStream();
			channelExec.setCommand(scriptFileName);
			channelExec.connect();
			channelExec.run();

			while(true){                
				if(channelExec.getExitStatus() == 0){
					System.out.println("exit-status: " + channelExec.getExitStatus());
					break;
				}
				try{
					Thread.sleep(1000);
				}catch(Exception ee){
					ee.printStackTrace();
				}
			}
			channelExec.disconnect();
			session.disconnect();
			System.out.println("Done...!!!");
			isSuccessstatus = true;
		}
		catch(Exception ex){
			ex.printStackTrace();
			isSuccessstatus = false;
		}
		return isSuccessstatus;
	}
	
		
	@Override
	public String viewOutputFileContent(String filepath) throws IOException {
		
		String sCurrentLine = "";
		String output = "" ;
		FileReader fr = null;
		try {
			fr = new FileReader(filepath);
		BufferedReader br = new BufferedReader(fr);
		br = new BufferedReader(new FileReader(filepath));
		while ((sCurrentLine = br.readLine()) != null) {
			output += sCurrentLine + "\n" ;
		}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return output;
	}

	@Override
	public LoanGraphDTO getgraphdata(String filepath) {
		
		LoanGraphDTO loanGraphDTO = new LoanGraphDTO();
		FileReader fr = null;
		String sCurrentLine ;
		double value;
		String fraud ;
		int range10 = 0,norange10  = 0;
		int range20 = 0 ,norange20 = 0;
		int range30 = 0 ,norange30 = 0;
		int range40 = 0 ,norange40 = 0;
		int range50 = 0,norange50 = 0;
		int range60 = 0 ,norange60 = 0;
		int range70 = 0 ,norange70 = 0;
		int range80 = 0 ,norange80 = 0;
		int range90 = 0 ,norange90 = 0;
		int range100 = 0 ,norange100 = 0;

		int count = 0;
		
		int defaultcount =0;
		int nondefaultcount =0;
		try {
			fr = new FileReader(filepath);
			BufferedReader br = new BufferedReader(fr);
			br = new BufferedReader(new FileReader(filepath));
			while ((sCurrentLine = br.readLine()) != null) {

				if(count!=0){
					value = Double.parseDouble(sCurrentLine.split(",")[2]);
					fraud = sCurrentLine.split(",")[1];

					if(fraud.equalsIgnoreCase("yes")){	
						
						defaultcount +=1;
						if(value>=0 && value <10){
							range10 += 1; 
						}else if(value>=10 && value <20){
							range20 += 1; 
						}else if(value>=20 && value <30){
							range30 += 1; 
						}else if(value>=30 && value <40){
							range40 += 1; 
						}else if(value>=40 && value <50){
							range50 += 1; 
						}else if(value>=50 && value <60){
							range60 += 1; 
						}else if(value>=60 && value <70){
							range70 += 1; 
						}else if(value>=70 && value <80){
							range80 += 1; 
						}else if(value>=80 && value <90){
							range90 += 1; 
						}else{
							range100 += 1; 
						}
					}
					else{
						nondefaultcount +=1;
						value = (100 - value);
						if(value>=0 && value <10){
							norange10 += 1; 
						}else if(value>=10 && value <20){
							norange20 += 1; 
						}else if(value>=20 && value <30){
							norange30 += 1; 
						}else if(value>=30 && value <40){
							norange40 += 1; 
						}else if(value>=40 && value <50){
							norange50 += 1; 
						}else if(value>=50 && value <60){
							norange60 += 1; 
						}else if(value>=60 && value <70){
							norange70 += 1; 
						}else if(value>=70 && value <80){
							norange80 += 1; 
						}else if(value>=80 && value <90){
							norange90 += 1; 
						}else{
							norange100 += 1; 
						}
					}
				}
				count= count + 1;
			}
			
			ArrayList<Integer> defaultarr = new ArrayList<Integer>();
			
			defaultarr.add(range10);
			defaultarr.add(range20);
			defaultarr.add(range30);
			defaultarr.add(range40);
			defaultarr.add(range50);
			defaultarr.add(range60);
			defaultarr.add(range70);
			defaultarr.add(range80);
			defaultarr.add(range90);
			defaultarr.add(range100);
			
			ArrayList<Integer> nondefaultarr = new ArrayList<Integer>();
			
			nondefaultarr.add(norange10);
			nondefaultarr.add(norange20);
			nondefaultarr.add(norange30);
			nondefaultarr.add(norange40);
			nondefaultarr.add(norange50);
			nondefaultarr.add(norange60);
			nondefaultarr.add(norange70);
			nondefaultarr.add(norange80);
			nondefaultarr.add(norange90);
			nondefaultarr.add(norange100);
			
			loanGraphDTO.setDefaultvalue(defaultcount);
			loanGraphDTO.setNondefaultvalue(nondefaultcount);
			
			loanGraphDTO.setDefaultvaluearr(defaultarr);
			loanGraphDTO.setNondefaultvaluearr(nondefaultarr);

		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return loanGraphDTO;
	}


	@Override
	public Object doDownload(HttpServletRequest request,HttpServletResponse response,String filename,String username) throws IOException {
		
		String fullPath = CommonConstant.FILELOCATION + username + "/Output/" + filename ;
		
		File downloadFile = new File(fullPath);
		FileInputStream inputStream = new FileInputStream(downloadFile);
		String mimeType= URLConnection.guessContentTypeFromName(downloadFile.getName());
		if (mimeType == null) {
			mimeType = "application/octet-stream";
		}
		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"",downloadFile.getName());
		response.setHeader(headerKey, headerValue);
		OutputStream outStream = response.getOutputStream();
		byte[] buffer = new byte[CommonConstant.BUFFER_SIZE];
		int bytesRead = -1;
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}
		inputStream.close();
		outStream.close();
		return bytesRead;
	}

	

}
