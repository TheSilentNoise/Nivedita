package com.LoanDefaultPredictor.Util;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Encryption {

	public static byte[] encryptBytesAndBase64Encode(byte[] bytes) throws Exception
	{
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		SecretKeySpec secretKey = new SecretKeySpec(CommonConstant.KEY, "AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedString = Base64.getEncoder().encode(cipher.doFinal(bytes));
		return encryptedString;
	}

	public static byte[] base64decodeAndDecryptBytes(byte[] base64EncodedEncryptedBytes) throws Exception
	{
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
		SecretKeySpec secretKey = new SecretKeySpec(CommonConstant.KEY, "AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(base64EncodedEncryptedBytes));
		return decryptedBytes;
	}


}
