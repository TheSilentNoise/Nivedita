package com.LoanDefaultPredictor.DTO;

import java.util.ArrayList;

public class LoanGraphDTO {
	
	private int defaultvalue ;
	private int nondefaultvalue ;
	private ArrayList<Integer> defaultvaluearr ;
	private ArrayList<Integer> nondefaultvaluearr ;
	
	
	public int getDefaultvalue() {
		return defaultvalue;
	}
	public void setDefaultvalue(int defaultvalue) {
		this.defaultvalue = defaultvalue;
	}
	public int getNondefaultvalue() {
		return nondefaultvalue;
	}
	public void setNondefaultvalue(int nondefaultvalue) {
		this.nondefaultvalue = nondefaultvalue;
	}
	public ArrayList<Integer> getDefaultvaluearr() {
		return defaultvaluearr;
	}
	public void setDefaultvaluearr(ArrayList<Integer> defaultvaluearr) {
		this.defaultvaluearr = defaultvaluearr;
	}
	public ArrayList<Integer> getNondefaultvaluearr() {
		return nondefaultvaluearr;
	}
	public void setNondefaultvaluearr(ArrayList<Integer> nondefaultvaluearr) {
		this.nondefaultvaluearr = nondefaultvaluearr;
	}
	
	
	
	
	
	

}
