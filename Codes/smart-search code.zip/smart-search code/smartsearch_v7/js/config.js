
//************************ Google API key *****************************
//googleAPIkey1 = "AIzaSyDjO5G646Zr_C-OK7f_mNXktYjwcn298nY";
//googleAPIkey2 = "AIzaSyBQWRexlkTnrHTf5eonkohhb0uyqSk3jh0" ;
//AIzaSyCIORKwM0yWet4fVzoGZcMNpwzYA703dJw = key3_newkey
	

//**********************************************************************


gOptions = {
  enabled: true,
  key: 'AIzaSyBQWRexlkTnrHTf5eonkohhb0uyqSk3jh0',
  //searchurl : "http://52.87.234.47:8081/elk/places/_search"
  searchurl : "http://172.18.100.103:9200/elk/places/_search"
}