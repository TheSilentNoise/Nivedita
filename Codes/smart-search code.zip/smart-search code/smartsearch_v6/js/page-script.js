	
$(document).ready(function() {
		
		$("#panelmap").hide();
		$("#noresult").html('');
		
		
		$.ui.autocomplete.prototype._renderItem = function (ul, item) {
		    item.label = item.label.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + $.ui.autocomplete.escapeRegex(this.term) + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>");
		    return $("<li></li>")
		            .data("item.autocomplete", item)
		            .append("<li>" + item.label + "</li>")
		            .appendTo(ul);
		};
		
		
		 if (gOptions.enabled){
			   var   key = gOptions.key;
			   var head= document.getElementsByTagName('head')[0];
			   var script= document.createElement('script');
			   script.type= 'text/javascript';
			   script.src= "https://maps.googleapis.com/maps/api/js?key="+key+"&callback=geocode&callback=myMap";
			   head.appendChild(script);
		} 
	
	//************************************** autocomplete search box **********************************************
				var namesarr = [];
				var unique = [];
				var cityarr = [];
				var ziparr = [];
				var searchurl = gOptions.searchurl;

				$("#autocomplete1").keyup(function(){
					var autocomplete_value1 = $("#autocomplete1").val();
					showBrandlist(autocomplete_value1,searchurl);
				});
				
				$("#autocomplete2").keyup(function(){
					var autocomplete_value2 = $("#autocomplete2").val();
					if(!isNaN(parseInt(autocomplete_value2))){
						showZiplist(autocomplete_value2,searchurl);
					}
					else{
						showCitylist(autocomplete_value2,searchurl);
					}
				});
				
			}); //end of document.ready
			
			
	//****************************** autocomplete for brand **********************************
	
	function showBrandlist(autocomplete_value1,searchurl){
		namesarr = [];
	//	var search_json = "{ \"query\": { \"match\" : { \"BRAND_ANALZD\" : { \"query\" : \""+ autocomplete_value1 +"\", \"analyzer\" : \"autocomplete_analyzer\" }}}}";
		var search_json = "{ \"query\": { \"bool\": { \"must\": [ { \"match\" :  { \"BRAND_ANALZD\" :  { \"query\" : \""+ autocomplete_value1 +"\", \"analyzer\" : \"autocomplete_analyzer\" }}}],\"should\" : [{\"term\": { \"MRCH_BRND_NTNL_FLG\": { \"value\": \"true\",\"boost\": 10 }}}]}}}";
		$.ajax({
			url : searchurl,
			type : "POST",
			data : search_json,
			success : function(result) {
				if (result != "") {
					var hitsObj = result.hits;
					for (i = 0; i < hitsObj.hits.length; i++) {
						var index = hitsObj.hits[i];
						var elem = index._source.BRAND;
						namesarr.push(elem);
					}
					var unique = findUnique(namesarr);
				}
				$("#autocomplete1").autocomplete({
					source : unique
				});
			}
		}); 
	}
			
  //****************************** autocomplete for Zip ***************************************			
	
	function showZiplist(autocomplete_value2,searchurl){
		ziparr = [];
		var search_json = "{ \"query\": { \"match\" : { \"ZIP_ANALZD\" : { \"query\" : \""+ autocomplete_value2 +"\", \"analyzer\" : \"autocomplete_analyzer\" }}}}";
				$.ajax({
					url : searchurl,
					type : "POST",
					data : search_json,
					success : function(result) {
						if (result != "") {
							var hitsObj = result.hits;
							for (i = 0; i < hitsObj.hits.length; i++) {
								var index = hitsObj.hits[i];
								var elem = index._source.ZIP;
								ziparr.push(elem);
							}
							var unique = findUnique(ziparr);
						}
						$("#autocomplete2").autocomplete({
							source : unique
						});
					}
				});
			}
			
			
  //************************* autocomplete for City ********************************************
			
			function showCitylist(autocomplete_value2,searchurl){
				cityarr = [];
				var search_json = "{ \"query\": { \"match\" : { \"CITY_ANALZD\" : { \"query\" : \""+ autocomplete_value2 +"\", \"analyzer\" : \"autocomplete_analyzer\" }}}}";
				$.ajax({
					url : searchurl,
					type : "POST",
					data : search_json,
					success : function(result) {
						if (result != "") {
							var hitsObj = result.hits;
							for (i = 0; i < hitsObj.hits.length; i++) {
								var index = hitsObj.hits[i];
								var elem = index._source.CITY + "," + index._source.STATE;
								cityarr.push(elem);
							}
							var unique = findUnique(cityarr);
							console.log(unique);
						}
						$("#autocomplete2").autocomplete({
							source : unique
						});
					}
				}); 
			}

			
	//************************************* push unique & top 5 element to auto-suggest array*********************************
	function findUnique(arr) {
		var result = [];
		var matches = [];
		arr.forEach(function(d) {
			if (result.indexOf(d) === -1)
				result.push(d);
		});
		var len = result.length;
		var count = 1 ;
		if(len>5){
		for(var i=0;i<=len;i++){
			if(count<=5){
				matches.push(result[i]);
				count ++ ;
			}else{
				break;
			}
		}
		}else{
			matches = result;
		}
		return matches;
	}
			
	//*********************************** fetch result set based on query parameter ************************************
	function fetchqueryresult() {
		$("#panelmap").hide();
		$('.table_data1').hide();
		$("#myTable2").hide();
		var location = $("#autocomplete2").val();
		var latlonval;
		if(location!==""){
			latlonval =  geocode(location);
		}else{
			latlonval =  geocode("60015");
		} 
	}
	
	function geocode (address){
		 geocoder = new google.maps.Geocoder();
		 geocoder.geocode({ 'address': address },
					function(results, status){
					  if (status == google.maps.GeocoderStatus.OK) {
						  var lat=results[0].geometry.location.lat();
					      var lng=results[0].geometry.location.lng();  
						  var loc = lat + ","+lng;
						  executeSearch(loc);
					  }
			       });
	}
	
	function executeSearch(latlonval){
		 var brand = $("#autocomplete1").val();
		 var searchurl = gOptions.searchurl;
		 var categoryarr = [];
		 
		 if(latlonval!==""){
		    	var latlonarr = latlonval.split(",");
				var latitute = latlonarr[0];
				var longitude = latlonarr[1];
		        var queryjson = "{\"query\": {\"bool\": {\"must\": {\"multi_match\": {\"query\": \""+ brand +"\","+
				"\"type\":  \"best_fields\", "+
				"\"fields\":  [ \"BRAND\"],"+
				"\"fuzziness\" : \"auto\"}},"+
	                    "\"filter\": {\"geo_distance\" : {\"distance\" : \"100km\",\"location\" : {"+
		                "\"lat\" : "+latitute +","+
		                "\"lon\" : "+longitude+"}}}}}}";            
				executesearch_callback(searchurl,queryjson);
		 }   
		    else{
		    	$("#myTable1").html('');
		    	$("#noresult").html('');
		    	$("#noresult").html('Invalid Address!!');
		    }
	 }
	
	function executesearch_callback(searchurl,queryjson){
		var brandarr = [];
		$.ajax({
			url : searchurl,
			type : "POST",
			data : queryjson,
			success : function(result) {
				if (result != "") {
					var hitsObj = result.hits;
					var hitlength = hitsObj.hits.length;
					if (hitlength !== 0) {
						$("#noresult").html('');
						$("#myTable1").html('');
						var thead = '<thead><tr>'
							+ "<th>Brand Name</th><th>Included in 5%</th><th>Category</th>"+
							+ '</tr></thead>';
						$("#myTable1").append(thead);
						for (i = 0; i < hitlength; i++) {
							var index = hitsObj.hits[i];
							var DBData = index._source;
							var brand = DBData.BRAND.toUpperCase();
							if(!brandarr.includes(brand)){
								brandarr.push(brand);
								createSearchTable(DBData);
							}
						}
						$('.table_data').show();
						$("#myTable1")
			            .dataTable({
			               "destroy": true, "bPaginate": true,"bSort": false,
			               "bLengthChange": true,"bInfo": true,"bFilter": false,
			               "lengthMenu": [[5,10,25,50,-1], [5,10,25,50,"All"]]
			             });
					}else{
						$('.table_data').hide();
						$("#myTable1").html('');
						$("#noresult").html("No brands found!!");
					}
				}
			}
		});  
		
	}
	
	
  //*************************************** initial SearchTable table creation  *************************************
	function createSearchTable(data) { 

	  var brand_name = data.BRAND ;
	  var addrs1 = data.ADD1 ;
	  var addrs2 = data.ADD2 ;
	  var zip = data.ZIP ;
	  var city = data.CITY ;
	  var state = data.STATE ;
	  var country = data.COUNTRY ;
	  var category = data.CATEGORY ;
	  var subcategory = data.SUB_CATEGORY;
	  var location = data.location;
	  var ntnlflag = data.MRCH_BRND_NTNL_FLG;
	  var tags = data.TAGS;
	  var include_5 ;
	  
	  if(category.toUpperCase()=='NON MONARCH'){
		  include_5='NO';
	  }else{
		  include_5='YES';
	  }
	 
	  
	  if(brand_name.includes('\'')){
		  brand_name = brand_name.replace("\'","\\'");
	  }
	 if(tags.includes('\'')){
		  tags = tags.replace(/'/g,"\\'");
	  }
	  
	  var td = '<td >'+
		 '<a href="#" onclick="createSearchtable2(\'' + brand_name + '\',\''+ addrs1 + '\',\''+ addrs2 + '\',\''+ zip + '\',\''+ city + '\',\''+ state + '\',\''+ country + '\',\''+ category + '\',\''+ subcategory + '\',\''+ location + '\',\''+ tags + '\')">' +
		       data.BRAND + '</td>' + 
		 '<td>'+ include_5 + '</td>'+
		 '<td>'+ data.CATEGORY + '</td>';
		  var row = '<tr>' + td + '</tr>';
		  $("#myTable1").append(row);
	}
	
	//*********************************** create 2nd Search table ******************************
	
	function createSearchtable2(brand_name,addrs1,addrs2,zip,city,state,country,category,subcategory,location,tags){
		
		$("#panelmap").hide();
		var latlonarr = location.split(",");
		var latitute = latlonarr[0];
		var longitude = latlonarr[1];
		var brandname = ("\""+brand_name+"\"").replace(/"/g,"\\\"");
		var search_json ="{\"query\":{\"bool\":{\"must\":[{\"script\":{"+
		      "\"script\" : \"if(doc['label-a'].value != null) {doc['label-a'].value.equalsIgnoreCase("+brandname+")}\"}}],"+
		      "\"filter\": {\"geo_distance\" : {\"distance\" : \"100km\",\"location\" : {\"lat\" :"+latitute+",\"lon\" :"+longitude+"}}}}}}";
		var search_url = gOptions.searchurl;
		
		createSearchtable2_callback(search_url,search_json);
	}
	
	function createSearchtable2_callback(search_url,search_json){
		$.ajax({
			url : search_url,
			type : "POST",
			data : search_json,
			success : function(result) {
				if (result != "") {
					var hitsObj = result.hits;
					var hitlength = hitsObj.hits.length;
					if (hitlength !== 0) {
						$("#noresult").html('');
						$("#myTable2").html('');
						var thead = '<thead><tr>'
							+ "<th>Brand Name</th><th>Location</th><th>Tags</th>"+
							+ '</tr></thead>';
						$("#myTable2").append(thead);
						for (i = 0; i < hitlength; i++) {
							var index = hitsObj.hits[i];
							var DBData = index._source;
							createSearchTable2_row(DBData);
						}
						$('.table_data1').show();
						$("#myTable2").show();
						$("#myTable2")
			            .dataTable({
			               "destroy": true,
			               "bPaginate": true,
			               "bSort": false,
			               "bLengthChange": true,
			               "bInfo": true,
			               "bFilter": false,
			               "lengthMenu": [[5,10,25,50,-1], [5,10,25,50,"All"]]
			             });
					}else{
						$('.table_data1').hide();
						$("#myTable2").html('');
					}
				}
			}
		});  
	}
	
	function createSearchTable2_row(data) { 

		  var brand_name = data.BRAND ;
		  var addrs1 = data.ADD1 ;
		  var addrs2 = data.ADD2 ;
		  var zip = data.ZIP ;
		  var city = data.CITY ;
		  var state = data.STATE ;
		  var country = data.COUNTRY ;
		  var category = data.CATEGORY ;
		  var subcategory = data.SUB_CATEGORY;
		  var location = data.location;
		  var ntnlflag = data.MRCH_BRND_NTNL_FLG;
		  var tags = data.TAGS;
		  
		  if(brand_name.includes('\'')){
			  brand_name = brand_name.replace("\'","\\'");
		  }
		  if(tags.includes('\'')){
			  tags = tags.replace(/'/g,"\\'");
		  }
		  
		var td = '<td >'+
		 '<a href="#" onclick="createSearchtablebyName(\'' + brand_name + '\',\''+ addrs1 + '\',\''+ addrs2 + '\',\''+ zip + '\',\''+ city + '\',\''+ state + '\',\''+ country + '\',\''+ category + '\',\''+ subcategory + '\',\''+ location + '\',\''+ tags + '\')">' +
		       data.BRAND + '</td>' + 
		  '<td>'+ addrs1+', '+city+', '+state+', '+zip + '</td>'+  
		  '<td>'+ tags + '</td>';
		  var row = '<tr>' + td + '</tr>';
		  $("#myTable2").append(row);
		  
}
  
	 //************************************* detailed desc Table table creation  *************************************
	 
	function createSearchtablebyName(brand_name,addrs1,addrs2,zip,city,state,country,category,subcategory,location,tags) {
		
		var lat = location.split(",")[0];
		var lon =  location.split(",")[1];
		$("#panelmap").show();
		myMap(lat,lon);
	}
	 
	//************************************ creation of google map *****************************************
	
	 function myMap (lat,lon){
		var mapOptions = {
				    center: new google.maps.LatLng(lat,lon),
				    zoom: 16,
				    mapTypeId: google.maps.MapTypeId.ROADMAP
		}
		var map = new google.maps.Map(document.getElementById("map"), mapOptions); 
	    var marker = new google.maps.Marker({
			        position: new google.maps.LatLng(lat,lon),
			        map: map
		}); 
	}	 
	 
	//*************************************** end of script ****************************************************
	
