
//************************ Google API key *****************************
//googleAPIkey1 = "AIzaSyDjO5G646Zr_C-OK7f_mNXktYjwcn298nY";
//googleAPIkey2 = "AIzaSyBQWRexlkTnrHTf5eonkohhb0uyqSk3jh0" ;
//AIzaSyCIORKwM0yWet4fVzoGZcMNpwzYA703dJw = key3_newkey
	

//**********************************************************************


gOptions = {
  enabled: true,
  key: 'AIzaSyBQWRexlkTnrHTf5eonkohhb0uyqSk3jh0',
  searchurl : "http://localhost:9200/elk/places/_search"
}